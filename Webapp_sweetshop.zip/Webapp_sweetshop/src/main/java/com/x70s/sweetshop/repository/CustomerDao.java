package com.x70s.sweetshop.repository;

public class CustomerDao {
}

package com.x70s.sweetshop.entity;

public class Product {
}

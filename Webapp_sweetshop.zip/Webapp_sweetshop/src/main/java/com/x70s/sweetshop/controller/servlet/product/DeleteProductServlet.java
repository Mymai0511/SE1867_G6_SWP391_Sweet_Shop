package com.x70s.sweetshop.controller.servlet.product;

public class DeleteProductServlet {
}

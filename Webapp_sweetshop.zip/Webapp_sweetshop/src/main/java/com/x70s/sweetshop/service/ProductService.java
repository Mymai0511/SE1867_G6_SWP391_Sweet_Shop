package com.x70s.sweetshop.service;

public class ProductService {
}

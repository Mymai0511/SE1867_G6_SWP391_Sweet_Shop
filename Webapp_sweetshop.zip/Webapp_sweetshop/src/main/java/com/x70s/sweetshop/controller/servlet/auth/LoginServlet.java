package com.x70s.sweetshop.controller.servlet.auth;

public class LoginServlet {
}

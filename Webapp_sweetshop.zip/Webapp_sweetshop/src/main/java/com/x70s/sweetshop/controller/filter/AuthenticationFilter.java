package com.x70s.sweetshop.controller.filter;

public class AuthenticationFilter {
}

package com.x70s.sweetshop.utils;

public class SShopHibernateUtils {
}
